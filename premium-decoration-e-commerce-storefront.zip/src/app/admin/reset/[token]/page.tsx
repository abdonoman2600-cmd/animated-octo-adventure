import { resolveResetToken } from "@/lib/admin-auth";
import { ResetForm } from "@/components/admin/AuthForms";

export const dynamic = "force-dynamic";

export default async function ResetPage({ params }: { params: Promise<{ token: string }> }) {
  const { token } = await params;
  return <ResetForm token={token} valid={!!(await resolveResetToken(token))} />;
}
